-- require all prototypes for exotic age here
-- for data stage only

--====================================================================================================
--MAIN CONTENT CODE
--====================================================================================================

-- prototype definitions for buildable entities get seperate files
-- those include prototype definitions for recipes, items, techs and categories

-- add general prototypes
require("exotic_prototypes")
-- add black hole
require("black-hole")
-- add holo signs
require("holo")