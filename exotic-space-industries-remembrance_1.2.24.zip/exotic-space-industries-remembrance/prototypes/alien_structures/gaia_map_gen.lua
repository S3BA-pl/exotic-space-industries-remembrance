gaia_map_gen = {}

gaia_map_gen.gaia = function()

end

return gaia_map_gen.gaia()