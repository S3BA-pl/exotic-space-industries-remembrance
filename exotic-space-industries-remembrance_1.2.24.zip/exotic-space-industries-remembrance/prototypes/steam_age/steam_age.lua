-- require all prototypes for dark age here
-- for data stage only

--====================================================================================================
--MAIN CONTENT CODE
--====================================================================================================

require("steam_prototypes")
require("coke-furnace")
require("steam-assembler")
require("steam-crusher")
require("steam-inserter")
require("steam-train")
require("steam-oil-pumpjack")
require("burner-heater")
require("fluid-heater")
require("heat_furnace")
require("basic-heat-pipe")
require("heat-chemical-plant")
require("fluid-boiler")
require("steam-miner")
require("tanks")
--============================================
