-- require all prototypes for dark age here
-- for data stage only

--====================================================================================================
--MAIN CONTENT CODE
--====================================================================================================

-- prototype definitions for buildable entities get seperate files
-- those include prototype definitions for recipes, items, techs and categories

require("lab")
require("burner-assembler")
require("burner_quarry")
require("dark_prototypes")
require("mechanical_inserter")
require("camp_fire")