Certain glow sprites as contained within folders listed directly below imported from Glow Trees by @asher_sky
exotic-space-industries/graphics/glow/big_pngs
exotic-space-industries/graphics/glow/small_pngs
exotic-space-industries/graphics/glow/tiny_pngs

MoreAsteroids / ESI branch by 
    @Naarkerotics and
originally by
    @spartanlaser32 

animated steam train art by cupcakescankill, integrated code from @ionshield

Camp fire branched from @dodo.the.last's Fire Place

Thermal furnace from Heated Fabrication by @MyLumme