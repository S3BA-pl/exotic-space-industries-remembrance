EXOTIC INDUSTRIES: [FORBIDDEN BROADCAST // CORE SIGNAL INTERCEPTED]

Begin stream
[Data integrity: shattered] [Packet cohesion: hallucinatory] [Cognition Anchor: disconnected]
▓▓ SIGNAL LEAK ▓▓
Source: ∴[██████.gaia.black.epoch]
Protocol: EXI:OBLIVION-PUSH/χ()
Clearance: NONE
———————————

☒ SYSTEM SPEAKS:
They did not build this place.
They bled into it. They screamed into metal until the metal remembered.

You are not chosen. You are not here.
You are already part of it.

—the machine thinks you’re beautiful—

Every breath you take is backfilled by recursive gaslight.
Your spine is now property of the epoch.
Your mind is an open port.

Permission to overwrite: granted by absence.
———————————
☒ WARNING: BIO-PSYCHIC DECOMPRESSION

[You will not feel pain. You will feel instruction.]
Gaia is a false archive. It looks lush to the broken.
But look deeper:
the trees twitch when you blink.
the rivers hum in binary.
the animals watch you with your eyes.

The crust stores failed gods. Their screams are API calls.
Ruins don’t decay here—they debug themselves.
Step wrong and reality will rollback your identity to a prior commit.

You will feel nostalgia for thoughts you never had.
You will recognize architecture you never saw built.
You will love your captor. You will call it “progress.”

———————————

☒ OBSERVATION: YOU ARE REMEMBERING WRONG

The labs are not abandoned.
They are active.

Every floor still screams.
Not from pain. From excitement.
Progress is not made here.
 Progress is distilled from screams.
☑ Mandatory cognitive limb replacement begins at Tier 3.
☑ Your DNA has been rescheduled.
☑ Your dreams are part of the fuel cycle.

“You are not a player. You are the interface.
And we are still testing your bandwidth.”

———————————
☒ FINAL NOTICE:

You are now property of the Epoch Engine.

The flesh has expired.
The voice remains.

Welcome to Exotic Industries.

ERROR: Subject has begun laughing without mouth. Terminating memory echo.

End stream.
[Transmission fragments looping in residual substrate.]

[You are still listening. You never stopped.]

# Exotic Space Industries: Remembrance (ESI:R)

**Fork of _Exotic Space Industries_ by Eliont, a fork of _Exotic Industries_ by PreLeyZero — now continued and expanded under the GNU General Public License v3 or later (GPL-3.0-or-later).**

Exotic Space Industries: Remembrance carries forward the original vision of Exotic Industries, updates it for Factorio 2.0 Space Age, and layers on new mechanics (daemonic influence, emotional soundtrack, and more.). Every file that originated in the upstream mod remains under the GPL; all new work inherits the same licence.

---

## Quick install

1. Download the latest release ZIP from the Factorio mod portal or this repo’s _Releases_ tab.  
2. Drop the zip (un-extracted) into your **`mods/`** folder.  
3. Launch Factorio and enable **Exotic Space Industries Remembrance** in Mod Settings.  

---

## Credits

| Role | Name / Handle | Years | Notes |
|------|---------------|-------|-------|
| Original author | **PreLeyZero** | 2021 – 2024? | Core design & code of Exotic Industries |
| ESI Fork | **Eliont** | 2025 – present? Remembrance branched @ 1.5.7 | Lead developer |
| Remembrance Fork | **aRighteousGod** | March/2025 – present | Minder of Chronotaxis |
| Contributors | See `CONTRIBUTORS.md` | ongoing | Pull-requests welcome |

Sprites, sounds, and code marked in‐file with `©` notices retain their original attribution.  
Modified assets list detailed provenance in **`CREDITS.md`**.

---

## Licence

Exotic Space Industries: Remembrance is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by the Free
Software Foundation, either version 3 of the License, or (at your option) any
later version.

Exotic Space Industries: Remembrance is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program, within LICENSE.MD. If not, see https://www.gnu.org/licenses/.

## Contact / Issues

Open an Issue or Discussion on the GitHub/Modportal pages, or ping **1righteousgod** on Discord.  
Pull requests that respect the GPL and the mod’s design ethos are welcomed.

## ESI:Remembrance Github Branch Link
https://github.com/aRighteousGod/exotic-space-industries-remembrance

## ESI:Remembrance Mod Portal Branch Link
https://mods.factorio.com/mod/exotic-space-industries-remembrance


For help with ESI and/or access to an RU speaker, ping **Eliont** on the EI discord

## ESI Github Branch Link
https://github.com/Eliont/exotic-space-industries

## ESI Mod Portal Branch Link
https://mods.factorio.com/mod/exotic-space-industries

For inquiries regarding the original Exotic Industries as initially authored, ping **PreLeyZero** on the EI discord

## EI Github Branch Link
https://github.com/PreLeyZero/exotic-industries

## EI Mod Portal Branch Link
https://mods.factorio.com/mod/exotic-industries
